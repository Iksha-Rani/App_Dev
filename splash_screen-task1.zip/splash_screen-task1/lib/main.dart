import 'package:flutter/material.dart';

void main() => runApp(  MaterialApp(
  debugShowCheckedModeBanner: false,
  home : Scaffold(
    backgroundColor: Colors.black12,
    appBar:AppBar(
      title:const Text('Cupidity'),
      centerTitle: true,
      backgroundColor: Colors.transparent,
      titleTextStyle: const TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 30.0,
        fontStyle: FontStyle.italic,
        color: Colors.white70,
        fontFamily: 'Cookie'
      ),
    ),
    body:Center(
         child:Column( children: [
           Container(
           child:Image(
             image:  AssetImage('assets/pic2.jpeg'),
             fit: BoxFit.fill,
             height: 573.9,
             width: 1000.0,


             alignment: Alignment.center,
           ),
  ),
           Text("Cupidity",
             textDirection: TextDirection.ltr,
             style: TextStyle(
               fontSize: 60.0,
               fontStyle: FontStyle.italic,
               fontWeight: FontWeight.bold,
               fontFamily: 'LoveLight',
               color: Colors.amber,
             ),

           ),

         ],


    ),
      ),
  ),
    )





    );






